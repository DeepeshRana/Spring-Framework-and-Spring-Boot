package in.pwskill.deepesh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityInMemoryAuthenticationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityInMemoryAuthenticationApplication.class, args);
	}

}
