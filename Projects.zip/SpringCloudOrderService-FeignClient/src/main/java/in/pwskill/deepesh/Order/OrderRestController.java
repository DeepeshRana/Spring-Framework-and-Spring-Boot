package in.pwskill.deepesh.Order;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import in.pwskill.deepesh.consumer.ICartConsumer;

@RestController
@RequestMapping("/v1/api/order")
public class OrderRestController {
	
	/*
	 * Method 	: get
	 * path 	: /place
	 * output 	: R.T<String>
	 * url 		: v1/api/order/place
	 * 
	 */
	
	@Autowired
	private ICartConsumer iCartConsumer;
	
	@GetMapping("/place")
	public ResponseEntity<String> getProduct(){
		
		String cartResponce = iCartConsumer.getProduct().getBody();
		return ResponseEntity.ok("ORDER PLACE WITH => " + cartResponce);
	}

}
